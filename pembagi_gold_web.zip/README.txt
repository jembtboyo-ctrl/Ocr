PEMBAGI GOLD TIM - VERSI WEB

File utama:
index.html

Cara paling mudah:
1. Upload folder/file ini ke layanan static hosting seperti Cloudflare Pages, Netlify, atau GitHub Pages.
2. Setelah dipublikasikan, bagikan URL website kepada anggota tim.
3. Pengguna cukup membuka URL -> Upload Screenshot -> Baca Gambar -> periksa hasil -> Hitung Hadiah.

Catatan:
- OCR memakai Tesseract.js dari CDN, jadi perangkat perlu koneksi internet saat membaca gambar.
- Data pemain diproses di browser pengguna; tidak perlu database untuk fungsi dasar.
